#include "stdafx.h"
#include "storeScene.h"

HRESULT storeScene::init()
{
	
	return S_OK;
}

void storeScene::release()
{
}

void storeScene::update()
{


}

void storeScene::render()
{

}
