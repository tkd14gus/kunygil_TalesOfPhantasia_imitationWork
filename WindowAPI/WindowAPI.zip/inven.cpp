#include "stdafx.h"
#include "inven.h"


HRESULT inven::init()
{

	return S_OK;
}

void inven::release()
{
}

void inven::update()
{


}

void inven::render()
{

}
