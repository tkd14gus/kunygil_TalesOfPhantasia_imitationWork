#include "stdafx.h"
#include "inGameScene.h"

HRESULT inGameScene::init()
{

	return S_OK;
}

void inGameScene::release()
{
}

void inGameScene::update()
{

}

void inGameScene::render()
{

}
