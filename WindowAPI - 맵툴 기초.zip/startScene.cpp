#include "stdafx.h"
#include "startScene.h"

HRESULT startScene::init()
{
	
	return S_OK;
}

void startScene::release()
{
}

void startScene::update()
{

}

void startScene::render()
{

}
